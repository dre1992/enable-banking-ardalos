---
title: "{APP_NAME}"
---

# {APP_NAME}

A personal, non-commercial application for accessing the operator's own bank
account information via PSD2 Open Banking APIs. This site exists to host the
legal documents required for registration as a restricted-access third-party
provider with [Enable Banking](https://enablebanking.com).

- [Privacy Policy](./privacy/)
- [Terms of Service](./terms/)

**Data protection contact:** {YOUR_EMAIL}
